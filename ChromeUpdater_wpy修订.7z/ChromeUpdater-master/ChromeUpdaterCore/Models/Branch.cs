﻿namespace ChromeUpdater
{
    public enum Branch
    {
        Stable,
        Beta,
        Dev,
        Canary
    }
}

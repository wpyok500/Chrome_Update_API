﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GetIPbyChinaz
{
    class Program
    {
        static void Main(string[] args)
        {

            //Console.BackgroundColor = ConsoleColor.Blue;
            //Console.ForegroundColor = ConsoleColor.White;
            //Console.WriteLine("White on blue.");
            //Console.WriteLine("Another line.");
            //Console.ResetColor();
            //Console.SetWindowSize(300, 100);
            //Console.SetWindowPosition(0, 0);
            try
            {
                Console.SetWindowSize(60, 15);
                Console.SetBufferSize(60, 15);
                
            }
            catch (Exception)
            {

            }

            //Console.WriteLine(Console.WindowWidth);
            //Console.WriteLine(Console.WindowHeight);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("开始获取chrome更新服务器ip。。。。。。");
            Console.ResetColor();
            Console.WriteLine();

            string time = System.DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString();
            string host = "tools.google.com";
            string guid = Guid.NewGuid().ToString("D");
            guid = "7e7a94cb-beb2-4dea-807e-4892d0f45909";

            string url = $"https://ping.chinaz.com/iframe.ashx?t=ping&callback=jQuery111308061257671237883_{time}";
            string referer = $"https://ping.chinaz.com/{host}";
            //guid=7e7a94cb-beb2-4dea-807e-4892d0f45909&host=tools.google.com&ishost=0&isipv6=0&encode=dkxSQKZidHHpWGvk6leI~DfuLCOFiYu|&checktype=0
            string postdata = $"guid={guid}&host={host}&ishost=0&isipv6=0&encode=dkxSQKZidHHpWGvk6leI~DfuLCOFiYu|&checktype=0";
            string outhtml = string.Empty;
            
            var t = Task.Run(() => {
                outhtml = Request(url, postdata, referer);
            });
            t.Wait();
            Console.WriteLine(outhtml);

            if (outhtml.Contains("谷歌云"))
            {  
                string ip = Regex.Match(outhtml, @"\d+\.\d+\.\d+\.\d+").Value.ToString();
                //WriteColor($"获取到chrome更新服务器ip为\t[{ip}]", ConsoleColor.Green);
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine();
                Console.Write("获取到chrome更新服务器ip为\t");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(ip);
                Console.ResetColor();
                Console.WriteLine();

                //Console.WriteLine("================================================");
                Console.WriteLine();
                Console.WriteLine("开始修改host");
                Console.WriteLine();

                Process process = new Process();
                process.StartInfo.FileName = "cmd.exe";
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.CreateNoWindow = true;
                process.Start();
                process.StandardInput.WriteLine("attrib -r -a -s -h %windir%\\system32\\drivers\\etc\\hosts & exit");
                process.WaitForExit();
                process.Close();

                string hostspath = Path.Combine(System.Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers\\etc\\hosts");
                List<string> list = File.ReadAllLines(hostspath).ToList();
                list.RemoveAll(x => x.Contains("tools.google.com"));
                foreach (var item in list.ToArray())
                {
                    if (item.Contains("dl.google.com"))
                    {
                        list.Remove(item);
                    }
                }
                list.Add($"{ip}  tools.google.com");
                list.Add($"{ip}  dl.google.com");
                //File.WriteAllLines(System.Environment.CurrentDirectory + "\\hosts", list.ToArray());
                File.WriteAllLines(hostspath, list.ToArray());
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("host修改完成");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("获取chrome更新服务器ip失败，请联系作者");
                Console.ResetColor();
            }
            
            Console.ReadLine();
        }

        static void WriteColor(string message, ConsoleColor color)
        {
            var pieces = Regex.Split(message, @"(\[[^\]]*\])");

            for (int i = 0; i < pieces.Length; i++)
            {
                string piece = pieces[i];

                if (piece.StartsWith("[") && piece.EndsWith("]"))
                {
                    Console.ForegroundColor = color;
                    piece = piece.Substring(1, piece.Length - 2);
                }

                Console.Write(piece);
                Console.ResetColor();
            }

            
            Console.WriteLine();
        }

        private static string Request(string url, string postdata, string referer)
        {
            string Content_Type = "application/x-www-form-urlencoded; charset=UTF-8";
            HttpWebRequest hwr = (HttpWebRequest)HttpWebRequest.Create(url);
            hwr.Method = "post";
            hwr.ContentType = Content_Type;
            hwr.KeepAlive = true;
            hwr.Referer = referer;

            byte[] py = Encoding.UTF8.GetBytes(postdata);
            hwr.ContentLength = py.Length;
            using (Stream sr = hwr.GetRequestStream())
            {
                sr.Write(py, 0, py.Length);
            }
            string outhtml = string.Empty;
            using (HttpWebResponse hwrs = (HttpWebResponse)hwr.GetResponse())
            {
                if (hwrs.ContentType.ToLower().Equals("gzip"))
                {
                    outhtml = new StreamReader(new GZipStream(hwrs.GetResponseStream(),CompressionMode.Decompress)).ReadToEnd();
                }
                else if (hwrs.ContentType.ToLower().Equals("deflate"))
                {
                    outhtml = new StreamReader(new DeflateStream(hwrs.GetResponseStream(), CompressionMode.Decompress)).ReadToEnd();
                }
                else
                {
                    outhtml = new StreamReader(hwrs.GetResponseStream()).ReadToEnd();
                }
            }
            return outhtml;
        }
    }
}

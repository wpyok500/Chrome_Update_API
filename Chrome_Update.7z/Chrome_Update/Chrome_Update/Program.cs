﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebRequestHellp;
using MihaZupan;
using System.Xml;

namespace Chrome_Update
{
    class Program
    {
        static void Main(string[] args)
        {
            String url = "https://tools.google.com/service/update2";
            string postdata = @"<?xml version='1.0' encoding='UTF-8'?>
<request protocol='3.0' version='1.3.23.9' shell_version='1.3.21.103' ismachine='0'
    sessionid='{3597644B-2952-4F92-AE55-D315F45F80A5}' installsource='ondemandcheckforupdate'
    requestid='{CD7523AD-A40D-49F4-AEEF-8C114B804658}' dedup='cr'>
<hw sse='1' sse2='1' sse3='1' ssse3='1' sse41='1' sse42='1' avx='1' physmemory='12582912' />
<os platform='win' version='6.3' arch='x64'/>
<app appid='{8A69D345-D564-463C-AFF1-A69D9E530F96}' ap='x64-stable-multi-chrome' version='' nextversion='' lang='' brand='GGLS' client=''><updatecheck/></app>
</request>";
            string outhtml = string.Empty;
            HttpToSocks5Proxy proxy = new HttpToSocks5Proxy("127.0.0.1", 10808);
            RequestHellp.Proxy = proxy;
            RequestHellp.HttpHelp(url, "post", postdata, null, "application/x-www-form-urlencoded", null, ref outhtml);
            XmlDocument xd = new XmlDocument();
            xd.LoadXml(outhtml);
            List<string> list = new List<string>();
            string name = string.Empty;
            string hash_sha256 = string.Empty;
            string size = string.Empty;
            foreach (XmlNode item in xd.SelectNodes("//package"))
            {
                foreach (XmlAttribute item1 in item.Attributes)
                {
                    if (item1.Name.Equals("name"))
                    {
                        name = item1.Value;
                    }
                    if (item1.Name.Equals("hash_sha256"))
                    {
                        hash_sha256 = item1.Value;
                    }
                    if (item1.Name.Equals("size"))
                    {
                        size = item1.Value;
                    }
                }
            }
            foreach (XmlNode item in xd.SelectNodes("//url"))
            {
                foreach (XmlAttribute item1 in item.Attributes)
                {
                    if (item1.Name.Equals("codebase"))
                    {
                        list.Add(item1.Value + name);
                    }
                }
                
            }
        }
    }
}
